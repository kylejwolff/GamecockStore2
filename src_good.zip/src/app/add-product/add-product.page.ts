import { Component, OnInit, ViewChild } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup, Form } from '@angular/forms';
import { Router, RouterOutlet, ActivationStart } from '@angular/router';

import { ItemService } from '../item.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.page.html',
  styleUrls: ['./add-product.page.scss'],
})
export class AddProductPage implements OnInit {

  new_product_form: FormGroup;

  constructor(
    private router: Router,
    public formBuilder: FormBuilder,
    public itemService: ItemService
  ) { }

  ngOnInit() {

    this.new_product_form = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      price: new FormControl('', Validators.required),
      category: new FormControl('', Validators.required),
      image: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required)
    });
  }

  createProduct(value){
    this.itemService.createProduct(value.name,value.price,value.category,value.image,value.description);

    this.goBack();
  }

  goBack(){
    this.router.navigate(['/tabs']);
  }

}
