import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Storage } from '@ionic/storage';

import * as firebase from 'Firebase';

import { Events } from '@ionic/angular'

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  db = firebase.firestore();
  usertype="visitor";

  //ref = firebase.database().ref('products/');
  //ref2 = firebase.database().ref('orders/');
  products:Array<any>=[];
  orders:Array<any>=[];
  cart:Array<any>=[];

  constructor(public events: Events) {

    var self=this;

    this.db.collection("products").onSnapshot(function(querySnapshot) {
        console.log("products list changed...........");
        self.products = [];
        querySnapshot.forEach(function(doc) {
          //console.log("pushing product");
            var item = doc.data();
            self.products.push({
              id:doc.id,
              name:item.name,
              price:item.price,
              category:item.category,
              img:item.img,
              description:item.description
            })
        });
        self.events.publish('dataloaded',Date.now());
        console.log("products reloaded");
    });
    if (this.usertype == "visitor"){
      console.log("no orders for visitors");
      self.orders = [];
    }
    else{
      var uid = firebase.auth().currentUser.uid;
      this.db.collection("orders").where("uid", "==", uid)
      .onSnapshot(function(querySnapshot) {
        console.log("loading orders for: "+uid);
        self.orders = [];
        querySnapshot.forEach(function(doc) {
          var item = doc.data();
          self.orders.push({
            id:doc.id,
            total:item.total,
            quantity:item.quantity,
            name:item.name,
            date:item.date,
            uid:item.uid
          })
        })
      })
    }
  }// end of constructor

  setUserType(type){
    var self = this;
    this.usertype = type;
    console.log("usertype set as: "+type);
    if(this.usertype == "visitor"){
      console.log("No orders for visitors");
      self.orders = [];
    }
    else{
      var uid = firebase.auth().currentUser.uid;
      this.db.collection("orders").where("uid", "==", uid)
      .onSnapshot(function(querySnapshot){
        console.log("loading orders for: "+uid);
        self.orders = [];
        querySnapshot.forEach(function(doc){
          var item = doc.data();
          self.orders.push({
            id:doc.id,
            total:item.total,
            quantity:item.quantity,
            name:item.name,
            date:item.date,
            uid:item.uid
          })
        })
      })
    }
  }

  getProducts(){
    return this.products;
  } 

  createProduct(name,price,category,image,description){
    if(this.usertype != "owner"){
      console.log("visitors cannot create products");
    }
    else{
      var db = firebase.firestore();
      db.collection("products").add({
        'name': name,
        'price': price,
        'category': category,
        'img': image,
        'description': description
      })
      .then(function(docRef){
        console.log("Document written with ID: ", docRef.id);
      })
      .catch(function(error){
        console.error("Error adding document: ", error);
      })
    }
  }

  deleteProduct(id){
    var db = firebase.firestore();
    let newInfo = db.collection('products').doc(id).delete();
    console.log("Product deleted:"+id);
  }

  deleteOrder(id){
    var db = firebase.firestore();
    let newInfo = db.collection('orders').doc(id).delete();
    console.log("Order deleted:"+id);
  }

  updateProduct(newValues){
    console.log(newValues.id);

    let newInfo = firebase.database().ref('products/'+newValues.id).update(newValues);
  }

  getOrders(){
    return this.orders;
  }

  addItem(total,name,quantity){
    if(this.usertype == "visitor"){
      console.log("visitors cannot add items to cart");
    }
    // else{
    //   var db = firebase.firestore();
    //   db.collection("users").doc(user.uid).set({
    //     'email':user.email,
    //     'type':'owner'
    //   });
    // }
  }

  createOrder(total,quantity,name){
    if(this.usertype == "visitor"){
      console.log("visitors cannot create orders");
    }
    else{
      var db = firebase.firestore();
      db.collection("orders").add({
        'total': total,
        'quantity': quantity,
        'name': name,
        'date': Date(),  //TODO make this more usefull
        'uid': firebase.auth().currentUser.uid
      })
      .then(function(docRef){
        console.log("Document written with ID: ", docRef.id);
      })
      .catch(function(error){
        console.error("Error adding document: ", error);
      })
    }
  }
}


export const snapshotToArray = snapshot => {
  let returnArr = [];

  snapshot.forEach(childSnapshot => {
    let item = childSnapshot.val();
    item.key = childSnapshot.key;
    console.log(item);
    returnArr.push(item);
  });

  return returnArr;
}
